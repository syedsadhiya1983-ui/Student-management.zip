# Student Management System

A simple Java full-stack CRUD application using:

- Java 17
- Spring Boot
- Spring JDBC (JdbcTemplate)
- MySQL
- HTML/CSS/JavaScript
- Maven

## 1. Create the database

Run `database.sql` in MySQL.

## 2. Configure MySQL

Open:

`src/main/resources/application.properties`

Change:

`spring.datasource.password=YOUR_MYSQL_PASSWORD`

to your MySQL password.

## 3. Run the application

From the project directory:

`mvn spring-boot:run`

Or run `StudentApplication.java` from your IDE.

## 4. Open the application

Open:

`http://localhost:8080`

## REST endpoints

GET    /api/students
GET    /api/students/{id}
POST   /api/students
PUT    /api/students/{id}
DELETE /api/students/{id}

Example POST body:

{
  "name": "Arun",
  "email": "arun@example.com",
  "course": "Java"
}

## Architecture

Browser -> REST Controller -> Service -> Repository -> MySQL

The repository uses Spring's JdbcTemplate, so the project demonstrates JDBC-style database access without using JPA.
