const API = "/api/students";

async function loadStudents() {
    const response = await fetch(API);
    const students = await response.json();

    const table = document.getElementById("studentTable");
    table.innerHTML = "";

    students.forEach(student => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${student.id}</td>
            <td>${student.name}</td>
            <td>${student.email}</td>
            <td>${student.course}</td>
            <td><button onclick="deleteStudent(${student.id})">Delete</button></td>
        `;
        table.appendChild(row);
    });
}

document.getElementById("studentForm").addEventListener("submit", async (event) => {
    event.preventDefault();

    const student = {
        name: document.getElementById("name").value,
        email: document.getElementById("email").value,
        course: document.getElementById("course").value
    };

    await fetch(API, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(student)
    });

    event.target.reset();
    loadStudents();
});

async function deleteStudent(id) {
    await fetch(`${API}/${id}`, { method: "DELETE" });
    loadStudents();
}

loadStudents();
