package com.example.student.repository;

import com.example.student.model.Student;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class StudentRepository {
    private final JdbcTemplate jdbcTemplate;

    public StudentRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Student> findAll() {
        String sql = "SELECT id, name, email, course FROM students";
        return jdbcTemplate.query(sql, (rs, rowNum) ->
                new Student(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("course")
                ));
    }

    public Student findById(int id) {
        String sql = "SELECT id, name, email, course FROM students WHERE id = ?";
        List<Student> students = jdbcTemplate.query(sql, (rs, rowNum) ->
                new Student(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("course")
                ), id);

        return students.isEmpty() ? null : students.get(0);
    }

    public Student save(Student student) {
        String sql = "INSERT INTO students(name, email, course) VALUES (?, ?, ?)";
        jdbcTemplate.update(sql, student.getName(), student.getEmail(), student.getCourse());
        return findLastInsertedStudent();
    }

    public int update(int id, Student student) {
        String sql = "UPDATE students SET name = ?, email = ?, course = ? WHERE id = ?";
        return jdbcTemplate.update(sql, student.getName(), student.getEmail(), student.getCourse(), id);
    }

    public int delete(int id) {
        return jdbcTemplate.update("DELETE FROM students WHERE id = ?", id);
    }

    private Student findLastInsertedStudent() {
        String sql = "SELECT id, name, email, course FROM students ORDER BY id DESC LIMIT 1";
        return jdbcTemplate.queryForObject(sql, (rs, rowNum) ->
                new Student(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("course")
                ));
    }
}
